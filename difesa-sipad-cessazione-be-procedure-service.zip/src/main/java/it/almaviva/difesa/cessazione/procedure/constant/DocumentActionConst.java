package it.almaviva.difesa.cessazione.procedure.constant;

public class DocumentActionConst {

    public static final String DETTAGLI_DOCUMENTO = "Dettagli documento";
    public static final String VISUALIZZA_DOCUMENTO = "Visualizza documento";
    public static final String MODIFICA = "Modifica";
    public static final String FIRMA = "Firma";
    public static final String SEGNATURA = "Segnatura";
    public static final String PREDISPOSIZIONE = "Predisposizione";
    public static final String PROTOCOLLA = "Protocolla";
    public static final String PREDISPONI_ADHOC = "Predisponi su AdHoc";
    public static final String APPROVAZIONE_ADHOC = "Invia per approvazione su AdHoc";
    public static final String ELIMINA = "Elimina";
    public static final String STERILIZZA = "Sterilizza";
    public static final String ACQUISISCI_PROTOCOLLO = "Acquisisci protocollo";
    public static final String INSERISCI_NOTIFICA = "Inserisci notifica";
    public static final String CAMBIA_NOME = "Cambia nome";

}
