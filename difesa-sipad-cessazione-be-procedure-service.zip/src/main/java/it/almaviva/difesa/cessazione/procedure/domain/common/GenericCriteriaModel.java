package it.almaviva.difesa.cessazione.procedure.domain.common;

public interface GenericCriteriaModel { }