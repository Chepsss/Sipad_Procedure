package it.almaviva.difesa.cessazione.procedure.model.common;

import it.almaviva.difesa.cessazione.procedure.domain.common.GenericCriteriaModel;

public class GenericRequest implements GenericCriteriaModel {
}
