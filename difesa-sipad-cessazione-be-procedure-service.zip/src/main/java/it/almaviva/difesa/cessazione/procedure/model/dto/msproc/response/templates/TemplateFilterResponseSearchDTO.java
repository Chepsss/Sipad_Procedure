package it.almaviva.difesa.cessazione.procedure.model.dto.msproc.response.templates;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TemplateFilterResponseSearchDTO extends TemplateInfoDTO {

    private String templateTypeDescription;

}
