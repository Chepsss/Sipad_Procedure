package it.almaviva.difesa.cessazione.procedure.domain.common;

import org.springframework.data.domain.Sort;

public interface Sortable {

    Sort getSort();
}