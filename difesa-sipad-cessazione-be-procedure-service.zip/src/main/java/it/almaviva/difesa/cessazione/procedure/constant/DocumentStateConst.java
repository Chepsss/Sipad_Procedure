package it.almaviva.difesa.cessazione.procedure.constant;

public class DocumentStateConst {

    public static final String IN_LAVORAZIONE = "IN_LAVORAZIONE";
    public static final String FIRMATO = "FIRMATO";
    public static final String PROTOCOLLATO = "PROTOCOLLATO";
    public static final String STERILIZZATO = "STERILIZZATO";
    public static final String IN_APPROVAZIONE = "IN_APPROVAZIONE";
    public static final String PREDISPOSTO_ADHOC = "PREDISPOSTO_ADHOC";
    public static final String IN_APPROVAZIONE_ADHOC = "IN_APPROVAZIONE_ADHOC";

}
