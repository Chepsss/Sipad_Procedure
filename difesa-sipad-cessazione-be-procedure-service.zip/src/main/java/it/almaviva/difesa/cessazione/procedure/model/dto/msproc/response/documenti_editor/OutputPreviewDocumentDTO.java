package it.almaviva.difesa.cessazione.procedure.model.dto.msproc.response.documenti_editor;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class OutputPreviewDocumentDTO implements Serializable {

    private String content;

}
